--
-- PostgreSQL database dump
--

\restrict HQlXzOZlxM6foSvbZhMVMtEEUK3CakR05015BKQcjRGEKVHlpErKCG40beI8zIw

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ai_model_type; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.ai_model_type AS ENUM (
    'vision',
    'nlp',
    'multimodal',
    'other'
);


ALTER TYPE public.ai_model_type OWNER TO vigil;

--
-- Name: ai_specialization; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.ai_specialization AS ENUM (
    'violence',
    'car_crash',
    'people_count',
    'other'
);


ALTER TYPE public.ai_specialization OWNER TO vigil;

--
-- Name: app_user_role; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.app_user_role AS ENUM (
    'admin',
    'officer',
    'security'
);


ALTER TYPE public.app_user_role OWNER TO vigil;

--
-- Name: car_crash_severity; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.car_crash_severity AS ENUM (
    'minor',
    'moderate',
    'severe',
    'critical'
);


ALTER TYPE public.car_crash_severity OWNER TO vigil;

--
-- Name: incident_severity; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.incident_severity AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public.incident_severity OWNER TO vigil;

--
-- Name: incident_status; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.incident_status AS ENUM (
    'active',
    'acknowledged',
    'dispatched',
    'resolved',
    'confirmed'
);


ALTER TYPE public.incident_status OWNER TO vigil;

--
-- Name: incident_type; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.incident_type AS ENUM (
    'violence',
    'crash',
    'people_count',
    'other'
);


ALTER TYPE public.incident_type OWNER TO vigil;

--
-- Name: notification_channel; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.notification_channel AS ENUM (
    'email',
    'sms',
    'push',
    'webhook'
);


ALTER TYPE public.notification_channel OWNER TO vigil;

--
-- Name: notification_priority; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.notification_priority AS ENUM (
    'low',
    'normal',
    'high',
    'urgent'
);


ALTER TYPE public.notification_priority OWNER TO vigil;

--
-- Name: violence_type; Type: TYPE; Schema: public; Owner: vigil
--

CREATE TYPE public.violence_type AS ENUM (
    'assault',
    'fight',
    'weapon',
    'other'
);


ALTER TYPE public.violence_type OWNER TO vigil;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_feedback; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.ai_feedback (
    id character varying NOT NULL,
    incident_id integer,
    related_incident_id integer,
    ai_model_id character varying,
    feedback_type character varying NOT NULL,
    confidence_before double precision,
    confidence_after double precision,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_feedback OWNER TO vigil;

--
-- Name: ai_model; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.ai_model (
    id character varying NOT NULL,
    name character varying NOT NULL,
    version character varying,
    type public.ai_model_type DEFAULT 'vision'::public.ai_model_type NOT NULL,
    specialization public.ai_specialization DEFAULT 'other'::public.ai_specialization NOT NULL,
    trained_from_dataset_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_model OWNER TO vigil;

--
-- Name: app_user; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.app_user (
    email character varying NOT NULL,
    name character varying NOT NULL,
    password_hash character varying NOT NULL,
    role public.app_user_role DEFAULT 'officer'::public.app_user_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_user OWNER TO vigil;

--
-- Name: camera; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.camera (
    id character varying NOT NULL,
    name character varying NOT NULL,
    location character varying,
    stream_url character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    model_id character varying
);


ALTER TABLE public.camera OWNER TO vigil;

--
-- Name: car_crash_incident; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.car_crash_incident (
    incident_id integer NOT NULL,
    vehicle_count integer,
    severity_level public.car_crash_severity,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.car_crash_incident OWNER TO vigil;

--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.dashboard (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    view_type character varying,
    last_updated timestamp without time zone,
    config jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dashboard OWNER TO vigil;

--
-- Name: demo_request; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.demo_request (
    id character varying NOT NULL,
    "fullName" character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    organization character varying NOT NULL,
    role character varying NOT NULL,
    cameras character varying NOT NULL,
    message text NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at_human character varying NOT NULL,
    updated_at character varying
);


ALTER TABLE public.demo_request OWNER TO vigil;

--
-- Name: demo_run; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.demo_run (
    id character varying NOT NULL,
    name character varying NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.demo_run OWNER TO vigil;

--
-- Name: incident; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.incident (
    internal_id integer NOT NULL,
    external_id character varying NOT NULL,
    run_id character varying,
    camera_id character varying NOT NULL,
    type public.incident_type NOT NULL,
    severity public.incident_severity NOT NULL,
    location character varying,
    model_id character varying,
    "timestamp" timestamp without time zone NOT NULL,
    status public.incident_status DEFAULT 'active'::public.incident_status NOT NULL,
    acknowledged boolean DEFAULT false NOT NULL,
    ack_by character varying,
    dispatched_to jsonb NOT NULL,
    assigned_security character varying,
    description text,
    confidence double precision NOT NULL,
    video_url character varying,
    "videoUrl" character varying,
    model character varying,
    "aiFeedback" boolean,
    "feedbackType" character varying,
    resolution_type character varying,
    extra_json jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_incident_conf_range CHECK (((confidence >= (0)::double precision) AND (confidence <= (100)::double precision)))
);


ALTER TABLE public.incident OWNER TO vigil;

--
-- Name: incident_action; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.incident_action (
    id integer NOT NULL,
    incident_internal_id integer NOT NULL,
    actor character varying NOT NULL,
    action character varying NOT NULL,
    from_status character varying,
    to_status character varying,
    detail_json jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_action OWNER TO vigil;

--
-- Name: incident_action_id_seq; Type: SEQUENCE; Schema: public; Owner: vigil
--

CREATE SEQUENCE public.incident_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incident_action_id_seq OWNER TO vigil;

--
-- Name: incident_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vigil
--

ALTER SEQUENCE public.incident_action_id_seq OWNED BY public.incident_action.id;


--
-- Name: incident_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: vigil
--

CREATE SEQUENCE public.incident_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incident_internal_id_seq OWNER TO vigil;

--
-- Name: incident_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vigil
--

ALTER SEQUENCE public.incident_internal_id_seq OWNED BY public.incident.internal_id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.notification (
    id character varying NOT NULL,
    incident_id integer,
    report_id character varying,
    channel public.notification_channel DEFAULT 'push'::public.notification_channel NOT NULL,
    priority public.notification_priority DEFAULT 'normal'::public.notification_priority NOT NULL,
    sent_at timestamp without time zone,
    delivered_at timestamp without time zone,
    payload jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification OWNER TO vigil;

--
-- Name: report; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.report (
    id character varying NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    format character varying NOT NULL,
    generated_date timestamp without time zone DEFAULT now() NOT NULL,
    file_path character varying,
    data_json jsonb,
    generated_by character varying
);


ALTER TABLE public.report OWNER TO vigil;

--
-- Name: retraining_dataset; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.retraining_dataset (
    id character varying NOT NULL,
    name character varying NOT NULL,
    sample_count integer,
    last_updated timestamp without time zone,
    location character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.retraining_dataset OWNER TO vigil;

--
-- Name: video_file; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.video_file (
    id character varying NOT NULL,
    camera_id character varying NOT NULL,
    filename character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size integer NOT NULL,
    duration double precision,
    video_type character varying NOT NULL,
    incident_id character varying,
    uploaded_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    video_metadata jsonb
);


ALTER TABLE public.video_file OWNER TO vigil;

--
-- Name: violence_incident; Type: TABLE; Schema: public; Owner: vigil
--

CREATE TABLE public.violence_incident (
    incident_id integer NOT NULL,
    violence_type public.violence_type,
    persons_involved integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.violence_incident OWNER TO vigil;

--
-- Name: incident internal_id; Type: DEFAULT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident ALTER COLUMN internal_id SET DEFAULT nextval('public.incident_internal_id_seq'::regclass);


--
-- Name: incident_action id; Type: DEFAULT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident_action ALTER COLUMN id SET DEFAULT nextval('public.incident_action_id_seq'::regclass);


--
-- Data for Name: ai_feedback; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.ai_feedback (id, incident_id, related_incident_id, ai_model_id, feedback_type, confidence_before, confidence_after, created_at) FROM stdin;
\.


--
-- Data for Name: ai_model; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.ai_model (id, name, version, type, specialization, trained_from_dataset_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.app_user (email, name, password_hash, role, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: camera; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.camera (id, name, location, stream_url, is_active, created_at, model_id) FROM stdin;
\.


--
-- Data for Name: car_crash_incident; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.car_crash_incident (incident_id, vehicle_count, severity_level, created_at) FROM stdin;
\.


--
-- Data for Name: dashboard; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.dashboard (id, user_id, view_type, last_updated, config, created_at) FROM stdin;
\.


--
-- Data for Name: demo_request; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.demo_request (id, "fullName", email, phone, organization, role, cameras, message, status, created_at, created_at_human, updated_at) FROM stdin;
\.


--
-- Data for Name: demo_run; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.demo_run (id, name, started_at, ended_at, is_active) FROM stdin;
\.


--
-- Data for Name: incident; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.incident (internal_id, external_id, run_id, camera_id, type, severity, location, model_id, "timestamp", status, acknowledged, ack_by, dispatched_to, assigned_security, description, confidence, video_url, "videoUrl", model, "aiFeedback", "feedbackType", resolution_type, extra_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incident_action; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.incident_action (id, incident_internal_id, actor, action, from_status, to_status, detail_json, created_at) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.notification (id, incident_id, report_id, channel, priority, sent_at, delivered_at, payload, created_at) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.report (id, name, type, format, generated_date, file_path, data_json, generated_by) FROM stdin;
\.


--
-- Data for Name: retraining_dataset; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.retraining_dataset (id, name, sample_count, last_updated, location, created_at) FROM stdin;
\.


--
-- Data for Name: video_file; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.video_file (id, camera_id, filename, file_path, file_size, duration, video_type, incident_id, uploaded_by, created_at, updated_at, video_metadata) FROM stdin;
\.


--
-- Data for Name: violence_incident; Type: TABLE DATA; Schema: public; Owner: vigil
--

COPY public.violence_incident (incident_id, violence_type, persons_involved, created_at) FROM stdin;
\.


--
-- Name: incident_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vigil
--

SELECT pg_catalog.setval('public.incident_action_id_seq', 1, false);


--
-- Name: incident_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vigil
--

SELECT pg_catalog.setval('public.incident_internal_id_seq', 1, false);


--
-- Name: ai_feedback ai_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_feedback
    ADD CONSTRAINT ai_feedback_pkey PRIMARY KEY (id);


--
-- Name: ai_model ai_model_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_model
    ADD CONSTRAINT ai_model_pkey PRIMARY KEY (id);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (email);


--
-- Name: camera camera_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.camera
    ADD CONSTRAINT camera_pkey PRIMARY KEY (id);


--
-- Name: car_crash_incident car_crash_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.car_crash_incident
    ADD CONSTRAINT car_crash_incident_pkey PRIMARY KEY (incident_id);


--
-- Name: dashboard dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_pkey PRIMARY KEY (id);


--
-- Name: demo_request demo_request_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.demo_request
    ADD CONSTRAINT demo_request_pkey PRIMARY KEY (id);


--
-- Name: demo_run demo_run_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.demo_run
    ADD CONSTRAINT demo_run_pkey PRIMARY KEY (id);


--
-- Name: incident_action incident_action_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident_action
    ADD CONSTRAINT incident_action_pkey PRIMARY KEY (id);


--
-- Name: incident incident_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT incident_pkey PRIMARY KEY (internal_id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (id);


--
-- Name: retraining_dataset retraining_dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.retraining_dataset
    ADD CONSTRAINT retraining_dataset_pkey PRIMARY KEY (id);


--
-- Name: incident uq_incident_external_id; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT uq_incident_external_id UNIQUE (external_id);


--
-- Name: incident uq_incident_run_cam_type_video; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT uq_incident_run_cam_type_video UNIQUE (run_id, camera_id, type, video_url);


--
-- Name: video_file video_file_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.video_file
    ADD CONSTRAINT video_file_pkey PRIMARY KEY (id);


--
-- Name: violence_incident violence_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.violence_incident
    ADD CONSTRAINT violence_incident_pkey PRIMARY KEY (incident_id);


--
-- Name: idx_incident_camera_time; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX idx_incident_camera_time ON public.incident USING btree (camera_id, "timestamp");


--
-- Name: idx_incident_dedup; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX idx_incident_dedup ON public.incident USING btree (run_id, camera_id, type, "timestamp");


--
-- Name: idx_incident_recent; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX idx_incident_recent ON public.incident USING btree (status, "timestamp");


--
-- Name: idx_incident_type_time; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX idx_incident_type_time ON public.incident USING btree (type, "timestamp");


--
-- Name: ix_ai_feedback_ai_model_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_ai_feedback_ai_model_id ON public.ai_feedback USING btree (ai_model_id);


--
-- Name: ix_ai_feedback_incident_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_ai_feedback_incident_id ON public.ai_feedback USING btree (incident_id);


--
-- Name: ix_ai_feedback_related_incident_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_ai_feedback_related_incident_id ON public.ai_feedback USING btree (related_incident_id);


--
-- Name: ix_dashboard_user_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_dashboard_user_id ON public.dashboard USING btree (user_id);


--
-- Name: ix_demo_request_status; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_demo_request_status ON public.demo_request USING btree (status);


--
-- Name: ix_incident_action_incident_internal_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_action_incident_internal_id ON public.incident_action USING btree (incident_internal_id);


--
-- Name: ix_incident_camera_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_camera_id ON public.incident USING btree (camera_id);


--
-- Name: ix_incident_external_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_external_id ON public.incident USING btree (external_id);


--
-- Name: ix_incident_model_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_model_id ON public.incident USING btree (model_id);


--
-- Name: ix_incident_run_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_run_id ON public.incident USING btree (run_id);


--
-- Name: ix_incident_status; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_status ON public.incident USING btree (status);


--
-- Name: ix_incident_timestamp; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_timestamp ON public.incident USING btree ("timestamp");


--
-- Name: ix_incident_type; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_incident_type ON public.incident USING btree (type);


--
-- Name: ix_notification_incident_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_notification_incident_id ON public.notification USING btree (incident_id);


--
-- Name: ix_notification_report_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_notification_report_id ON public.notification USING btree (report_id);


--
-- Name: ix_report_generated_date; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_report_generated_date ON public.report USING btree (generated_date);


--
-- Name: ix_report_type; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_report_type ON public.report USING btree (type);


--
-- Name: ix_video_file_camera_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_video_file_camera_id ON public.video_file USING btree (camera_id);


--
-- Name: ix_video_file_incident_id; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_video_file_incident_id ON public.video_file USING btree (incident_id);


--
-- Name: ix_video_file_video_type; Type: INDEX; Schema: public; Owner: vigil
--

CREATE INDEX ix_video_file_video_type ON public.video_file USING btree (video_type);


--
-- Name: ai_feedback ai_feedback_ai_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_feedback
    ADD CONSTRAINT ai_feedback_ai_model_id_fkey FOREIGN KEY (ai_model_id) REFERENCES public.ai_model(id) ON DELETE SET NULL;


--
-- Name: ai_feedback ai_feedback_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_feedback
    ADD CONSTRAINT ai_feedback_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incident(internal_id) ON DELETE SET NULL;


--
-- Name: ai_feedback ai_feedback_related_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_feedback
    ADD CONSTRAINT ai_feedback_related_incident_id_fkey FOREIGN KEY (related_incident_id) REFERENCES public.incident(internal_id) ON DELETE SET NULL;


--
-- Name: ai_model ai_model_trained_from_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.ai_model
    ADD CONSTRAINT ai_model_trained_from_dataset_id_fkey FOREIGN KEY (trained_from_dataset_id) REFERENCES public.retraining_dataset(id) ON DELETE SET NULL;


--
-- Name: camera camera_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.camera
    ADD CONSTRAINT camera_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_model(id) ON DELETE SET NULL;


--
-- Name: car_crash_incident car_crash_incident_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.car_crash_incident
    ADD CONSTRAINT car_crash_incident_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incident(internal_id) ON DELETE CASCADE;


--
-- Name: dashboard dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_user(email) ON DELETE CASCADE;


--
-- Name: incident_action incident_action_incident_internal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident_action
    ADD CONSTRAINT incident_action_incident_internal_id_fkey FOREIGN KEY (incident_internal_id) REFERENCES public.incident(internal_id) ON DELETE CASCADE;


--
-- Name: incident incident_camera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT incident_camera_id_fkey FOREIGN KEY (camera_id) REFERENCES public.camera(id) ON DELETE RESTRICT;


--
-- Name: incident incident_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT incident_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_model(id) ON DELETE SET NULL;


--
-- Name: incident incident_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.incident
    ADD CONSTRAINT incident_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.demo_run(id) ON DELETE SET NULL;


--
-- Name: notification notification_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incident(internal_id) ON DELETE SET NULL;


--
-- Name: notification notification_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.report(id) ON DELETE SET NULL;


--
-- Name: report report_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.app_user(email) ON DELETE SET NULL;


--
-- Name: video_file video_file_camera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.video_file
    ADD CONSTRAINT video_file_camera_id_fkey FOREIGN KEY (camera_id) REFERENCES public.camera(id) ON DELETE RESTRICT;


--
-- Name: video_file video_file_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.video_file
    ADD CONSTRAINT video_file_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incident(external_id) ON DELETE SET NULL;


--
-- Name: video_file video_file_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.video_file
    ADD CONSTRAINT video_file_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.app_user(email) ON DELETE SET NULL;


--
-- Name: violence_incident violence_incident_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vigil
--

ALTER TABLE ONLY public.violence_incident
    ADD CONSTRAINT violence_incident_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incident(internal_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict HQlXzOZlxM6foSvbZhMVMtEEUK3CakR05015BKQcjRGEKVHlpErKCG40beI8zIw

